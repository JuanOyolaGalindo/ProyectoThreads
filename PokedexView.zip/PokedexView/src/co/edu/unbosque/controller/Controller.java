package co.edu.unbosque.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import co.edu.unbosque.view.Frame;

public class Controller implements ActionListener{

	private Frame f;
	
	public Controller() {
		f = new Frame();
		f.setVisible(false);
		
		f.p1.getJButton1().addActionListener(this);
		f.p1.getJButton2().addActionListener(this);
		f.p1.getAdel().addActionListener(this);
		f.p1.getAtr().addActionListener(this);
		f.p1.getSalir().addActionListener(this);
		
		f.p2.getJButton1().addActionListener(this);
		
		f.p3.getJButton1().addActionListener(this);
		run();
		
	}

	public void run() {
		f.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == f.p1.getJButton1()) {
			} else if(e.getSource() == f.p1.getJButton2()){
			} else if(e.getSource() == f.p1.getAdel()) {
			} else if(e.getSource() == f.p1.getAtr()) {
			} else if(e.getSource() == f.p1.getSalir()) {
			} else if(e.getSource() == f.p2.getJButton1()) {
			} else if(e.getSource() == f.p3.getJButton1()) {
		}
	}
}

