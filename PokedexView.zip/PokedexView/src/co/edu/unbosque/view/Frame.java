package co.edu.unbosque.view;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Frame extends JFrame{

	private static final long serialVersionUID = 1L;

	
	public Pane1 p1;

	public Pane2 p2;

	public Pane3 p3;

	public Frame() {

		setBounds(0,0,600,400);
		setLocationRelativeTo(null);
		setLayout(null);
		setResizable(false);
		setVisible(true);
		
		p1 = new Pane1();
		p1.setVisible(true);
		
		p2 = new Pane2();
		p2.setVisible(false);

		p3 = new Pane3();
		p3.setVisible(false);

		add(p1);
		add(p2);
		add(p3);
	}
}
