package co.edu.unbosque.view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;

public class Pane3 extends JPanel{

	private static final long serialVersionUID = 1L;
	
	private JButton JButton1;			private JButton JButton11;			private JButton JButton21;
	private JButton JButton2;			private JButton JButton12;			private JButton JButton22;
	private JButton JButton3;			private JButton JButton13;			private JButton JButton23;
	private JButton JButton4;			private JButton JButton14;			private JButton JButton24;
	private JButton JButton5;			private JButton JButton15;			private JButton JButton25;
	private JButton JButton6;			private JButton JButton16;			private JButton JButton26;
	private JButton JButton7;			private JButton JButton17;			private JButton JButton27;
	private JButton JButton8;			private JButton JButton18;			private JButton JButton28;
	private JButton JButton9;			private JButton JButton19;			private JButton JButton29;
	private JButton JButton10;			private JButton JButton20;			private JButton JButton30;
	
	private JButton atr, adel, salir;
	
	private JPanel izuno;
	private JPanel izdos;
	private JPanel iztres;
	private JPanel arr;
	
	private JLabel nombre, datos,img;
	public Pane3() {
		setBounds(0,0,600,400);
		setBackground(new Color(108, 52, 131));
		setLayout(null);
		setVisible(true);
		
		salir = new JButton("Salir");
		salir.setBounds(450,300,100,50);
		
		add(izq(), BorderLayout.WEST);
		add(npoke(), BorderLayout.EAST);
		add(arr(),BorderLayout.NORTH);
		add(salir,BorderLayout.SOUTH);
	}

	public JPanel izq() {
		JPanel izq = new JPanel();
		nombre = new JLabel("");
		datos = new JLabel("");
		img = new JLabel();
		izuno = new JPanel();
		izuno.setBackground(new Color(255,255,255));
		izuno.setBorder(new LineBorder(Color.BLACK));
		izuno.add(img);
		izdos = new JPanel();
		izdos.setBackground(new Color(255,255,255));
		izdos.setBorder(new LineBorder(Color.BLACK));
		izdos.add(datos);
		iztres = new JPanel();
		iztres.setBackground(new Color(255,255,255));
		iztres.setBorder(new LineBorder(Color.BLACK));
		iztres.add(nombre);
		izq.setLayout(new GridLayout(3,1));
		izq.setBounds(0,0,200,400);
		izq.setVisible(true);
		izq.add(izuno);
		izq.add(izdos);
		izq.add(iztres);
		return izq;
	}
	
	public JPanel arr() {
		arr = new JPanel();
		JLabel ncaja = new JLabel("Caja 3");
		atr = new JButton("Atras");
		atr.setActionCommand("Atras");
		adel = new JButton("Adelante");
		adel.setActionCommand("Adelante");
		
		arr.setBounds(200,0,400,70);
		arr.setVisible(true);
		arr.add(atr);
		arr.add(ncaja);
		arr.add(adel);
		return arr;
	}
	
	public JPanel npoke() {
		JPanel centro = new JPanel();
		centro.setLayout(new GridLayout(5,6));
		JButton1 = new JButton();				JButton11 = new JButton();				JButton21 = new JButton();
		JButton2 = new JButton();				JButton12 = new JButton();				JButton22 = new JButton();
		JButton3 = new JButton();				JButton13 = new JButton();				JButton23 = new JButton();
		JButton4 = new JButton();				JButton14 = new JButton();				JButton24 = new JButton();
		JButton5 = new JButton();				JButton15 = new JButton();				JButton25 = new JButton();
		JButton6 = new JButton();				JButton16 = new JButton();				JButton26 = new JButton();
		JButton7 = new JButton();				JButton17 = new JButton();				JButton27 = new JButton();
		JButton8 = new JButton();				JButton18 = new JButton();				JButton28 = new JButton();
		JButton9 = new JButton();				JButton19 = new JButton();				JButton29 = new JButton();
		JButton10 = new JButton();				JButton20 = new JButton();				JButton30 = new JButton();
		
		JButton1.setActionCommand("button3");					JButton11.setActionCommand("button3");					JButton21.setActionCommand("button3");
		JButton2.setActionCommand("button3");					JButton12.setActionCommand("button3");					JButton22.setActionCommand("button3");
		JButton3.setActionCommand("button3");					JButton13.setActionCommand("button3");					JButton23.setActionCommand("button3");
		JButton4.setActionCommand("button3");					JButton14.setActionCommand("button3");					JButton24.setActionCommand("button3");
		JButton5.setActionCommand("button3");					JButton15.setActionCommand("button3");					JButton25.setActionCommand("button3");
		JButton6.setActionCommand("button3");					JButton16.setActionCommand("button3");					JButton26.setActionCommand("button3");
		JButton7.setActionCommand("button3");					JButton17.setActionCommand("button3");					JButton27.setActionCommand("button3");
		JButton8.setActionCommand("button3");					JButton18.setActionCommand("button3");					JButton28.setActionCommand("button3");
		JButton9.setActionCommand("button3");					JButton19.setActionCommand("button3");					JButton29.setActionCommand("button3");
		JButton10.setActionCommand("button3");					JButton20.setActionCommand("button3");					JButton30.setActionCommand("button3");
		
		centro.setBounds(200,100,400,200);
		centro.setVisible(true);
		centro.add(JButton1);				centro.add(JButton11);				centro.add(JButton21);
		centro.add(JButton2);				centro.add(JButton12);				centro.add(JButton22);
		centro.add(JButton3);				centro.add(JButton13);				centro.add(JButton23);
		centro.add(JButton4);				centro.add(JButton14);				centro.add(JButton24);
		centro.add(JButton5);				centro.add(JButton15);				centro.add(JButton25);
		centro.add(JButton6);				centro.add(JButton16);				centro.add(JButton26);
		centro.add(JButton7);				centro.add(JButton17);				centro.add(JButton27);
		centro.add(JButton8);				centro.add(JButton18);				centro.add(JButton28);
		centro.add(JButton9);				centro.add(JButton19);				centro.add(JButton29);
		centro.add(JButton10);				centro.add(JButton20);				centro.add(JButton30);
		
		return centro;
	}

	public JButton getJButton1() {
		return JButton1;
	}

	public void setJButton1(JButton jButton1) {
		JButton1 = jButton1;
	}

	public JButton getJButton11() {
		return JButton11;
	}

	public void setJButton11(JButton jButton11) {
		JButton11 = jButton11;
	}

	public JButton getJButton21() {
		return JButton21;
	}

	public void setJButton21(JButton jButton21) {
		JButton21 = jButton21;
	}

	public JButton getJButton2() {
		return JButton2;
	}

	public void setJButton2(JButton jButton2) {
		JButton2 = jButton2;
	}

	public JButton getJButton12() {
		return JButton12;
	}

	public void setJButton12(JButton jButton12) {
		JButton12 = jButton12;
	}

	public JButton getJButton22() {
		return JButton22;
	}

	public void setJButton22(JButton jButton22) {
		JButton22 = jButton22;
	}

	public JButton getJButton3() {
		return JButton3;
	}

	public void setJButton3(JButton jButton3) {
		JButton3 = jButton3;
	}

	public JButton getJButton13() {
		return JButton13;
	}

	public void setJButton13(JButton jButton13) {
		JButton13 = jButton13;
	}

	public JButton getJButton23() {
		return JButton23;
	}

	public void setJButton23(JButton jButton23) {
		JButton23 = jButton23;
	}

	public JButton getJButton4() {
		return JButton4;
	}

	public void setJButton4(JButton jButton4) {
		JButton4 = jButton4;
	}

	public JButton getJButton14() {
		return JButton14;
	}

	public void setJButton14(JButton jButton14) {
		JButton14 = jButton14;
	}

	public JButton getJButton24() {
		return JButton24;
	}

	public void setJButton24(JButton jButton24) {
		JButton24 = jButton24;
	}

	public JButton getJButton5() {
		return JButton5;
	}

	public void setJButton5(JButton jButton5) {
		JButton5 = jButton5;
	}

	public JButton getJButton15() {
		return JButton15;
	}

	public void setJButton15(JButton jButton15) {
		JButton15 = jButton15;
	}

	public JButton getJButton25() {
		return JButton25;
	}

	public void setJButton25(JButton jButton25) {
		JButton25 = jButton25;
	}

	public JButton getJButton6() {
		return JButton6;
	}

	public void setJButton6(JButton jButton6) {
		JButton6 = jButton6;
	}

	public JButton getJButton16() {
		return JButton16;
	}

	public void setJButton16(JButton jButton16) {
		JButton16 = jButton16;
	}

	public JButton getJButton26() {
		return JButton26;
	}

	public void setJButton26(JButton jButton26) {
		JButton26 = jButton26;
	}

	public JButton getJButton7() {
		return JButton7;
	}

	public void setJButton7(JButton jButton7) {
		JButton7 = jButton7;
	}

	public JButton getJButton17() {
		return JButton17;
	}

	public void setJButton17(JButton jButton17) {
		JButton17 = jButton17;
	}

	public JButton getJButton27() {
		return JButton27;
	}

	public void setJButton27(JButton jButton27) {
		JButton27 = jButton27;
	}

	public JButton getJButton8() {
		return JButton8;
	}

	public void setJButton8(JButton jButton8) {
		JButton8 = jButton8;
	}

	public JButton getJButton18() {
		return JButton18;
	}

	public void setJButton18(JButton jButton18) {
		JButton18 = jButton18;
	}

	public JButton getJButton28() {
		return JButton28;
	}

	public void setJButton28(JButton jButton28) {
		JButton28 = jButton28;
	}

	public JButton getJButton9() {
		return JButton9;
	}

	public void setJButton9(JButton jButton9) {
		JButton9 = jButton9;
	}

	public JButton getJButton19() {
		return JButton19;
	}

	public void setJButton19(JButton jButton19) {
		JButton19 = jButton19;
	}

	public JButton getJButton29() {
		return JButton29;
	}

	public void setJButton29(JButton jButton29) {
		JButton29 = jButton29;
	}

	public JButton getJButton10() {
		return JButton10;
	}

	public void setJButton10(JButton jButton10) {
		JButton10 = jButton10;
	}

	public JButton getJButton20() {
		return JButton20;
	}

	public void setJButton20(JButton jButton20) {
		JButton20 = jButton20;
	}

	public JButton getJButton30() {
		return JButton30;
	}

	public void setJButton30(JButton jButton30) {
		JButton30 = jButton30;
	}

	public JPanel getIzuno() {
		return izuno;
	}

	public void setIzuno(JPanel izuno) {
		this.izuno = izuno;
	}

	public JPanel getIzdos() {
		return izdos;
	}

	public void setIzdos(JPanel izdos) {
		this.izdos = izdos;
	}

	public JPanel getIztres() {
		return iztres;
	}

	public void setIztres(JPanel iztres) {
		this.iztres = iztres;
	}

	public JButton getAtr() {
		return atr;
	}

	public void setAtr(JButton atr) {
		this.atr = atr;
	}

	public JButton getAdel() {
		return adel;
	}

	public void setAdel(JButton adel) {
		this.adel = adel;
	}

	public JButton getSalir() {
		return salir;
	}

	public void setSalir(JButton salir) {
		this.salir = salir;
	}

	public JLabel getNombre() {
		return nombre;
	}

	public void setNombre(JLabel nombre) {
		this.nombre = nombre;
	}

	public JLabel getDatos() {
		return datos;
	}

	public void setDatos(JLabel datos) {
		this.datos = datos;
	}

	public JLabel getImg() {
		return img;
	}

	public void setImg(JLabel img) {
		this.img = img;
	}
}
